# LIYA — Android Studio Project

A simple Android WebView wrapper for the LIYA interactive story prototype.

## Build the app

1. Install Android Studio (stable version) on a computer.
2. Extract `LIYA_Android_Project.zip`.
3. In Android Studio choose **Open** and select the `LIYA_Android_Project` folder.
4. Allow Gradle sync and install any requested Android SDK platform (API 35).
5. Connect an Android phone with USB debugging enabled, or start an emulator.
6. Press **Run**.

## Build an APK

In Android Studio:
- Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
- Android Studio will show the location of the generated APK.
- For a shareable release build, use **Build → Generate Signed Bundle / APK** and follow the signing wizard.

## Notes
- The game is bundled at `app/src/main/assets/index.html`.
- Story choices and progress use browser local storage inside the app.
- This is a starter project, not a Play Store-ready release. App signing, testing on devices, privacy review, and store assets are still needed.
